# Build Your Own World Design Document

**Partner 1:**

**Partner 2:**

## Classes and Data Structures
**Engine:**

- *checkKey*: depending on what letter is being typed, performs an action.
      (N for new world, S for end of seed, L for load world, Q for quit)
- *displayMenu:* STDraw the display menu.
  

**TileMap:** 
class for the game map (with coordinate points for each tile), representing the game as a graph.



*hasSpace*: will check if there is space in the TileMap to make whatever structure.

- *Coordinates:* x and y coordinates for the TileMap (width and height).

**Rooms**: will generate random width, height, and center point. have top right, top left, bottom right, bottom left coordinates

**Hallways:** will find two rooms and make a space between them. width of 1 or 2. make a path from the center of each room.

## Algorithms

## Persistence
