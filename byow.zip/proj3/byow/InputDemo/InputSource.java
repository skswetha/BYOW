package byow.InputDemo;

/**
 * Created by hug.
 */
public interface InputSource {
    char getNextKey();

    boolean possibleNextInput();
}
